import { WebSocketServer } from 'ws';
import { proofFor, randomToken } from './lib/proof.js';

/**
 * Localhost WebSocket end of the agent bridge. Every agent session runs its own server, so a
 * server takes the first free port of `span` ports from `port` and the extension connects to all
 * of them. The extension's service worker connects, both sides prove the shared token, then the
 * server forwards tool calls as requests and awaits the extension's responses. One extension
 * connection per server; the newest wins.
 */
export const BRIDGE_PORT_SPAN = 10;

export function createBridge({ port, token, version = '', log = () => {}, host = '127.0.0.1', requestTimeoutMs = 90e3, span = BRIDGE_PORT_SPAN }) {
    let wss = null;
    let closed = false;
    let client = null;
    let clientVersion = '';
    const pending = new Map();
    let seq = 0;

    const failAll = (reason) => {
        for (const entry of pending.values()) {
            clearTimeout(entry.timer);
            entry.reject(new Error(reason));
        }
        pending.clear();
    };

    const onConnection = (ws) => {
        const nonce = randomToken(16);
        let verified = false;
        ws.send(JSON.stringify({ type: 'challenge', nonce }));
        const ping = setInterval(() => {
            if (ws.readyState === ws.OPEN) {
                ws.send(JSON.stringify({ type: 'ping' }));
            }
        }, 20e3);
        ws.on('message', async (raw) => {
            let message;
            try {
                message = JSON.parse(String(raw));
            } catch {
                return;
            }
            if (message.type === 'hello') {
                if (message.proof !== (await proofFor(token, nonce)) || !message.nonce) {
                    log('a client failed the token proof');
                    ws.close(4001, 'bad token');
                    return;
                }
                verified = true;
                if (client && client !== ws) {
                    client.close(4003, 'replaced by a newer connection');
                }
                client = ws;
                clientVersion = message.version || '';
                ws.send(JSON.stringify({ type: 'welcome', proof: await proofFor(token, message.nonce), version }));
                log(`extension connected (v${clientVersion})`);
                return;
            }
            if (!verified || message.type !== 'response') {
                return;
            }
            const entry = pending.get(message.id);
            if (!entry) {
                return;
            }
            pending.delete(message.id);
            clearTimeout(entry.timer);
            if (message.error) {
                entry.reject(new Error(message.error.message || 'the extension reported an error'));
            } else {
                entry.resolve(message.result);
            }
        });
        ws.on('close', () => {
            clearInterval(ping);
            if (client === ws) {
                client = null;
                clientVersion = '';
                failAll('the extension disconnected');
                log('extension disconnected');
            }
        });
        ws.on('error', () => {});
    };

    const listenOn = (candidate) =>
        new Promise((resolve, reject) => {
            candidate.once('listening', resolve);
            candidate.once('error', reject);
        });

    const listening = (async () => {
        const last = port ? port + span - 1 : 0;
        for (let p = port; ; p += 1) {
            const candidate = new WebSocketServer({ host, port: p, path: '/extension' });
            try {
                await listenOn(candidate);
            } catch (e) {
                candidate.close();
                if (e.code !== 'EADDRINUSE') {
                    throw e;
                }
                if (p < last) {
                    log(`port ${p} is taken by another agent's server, trying ${p + 1}`);
                    continue;
                }
                throw new Error(
                    port === last
                        ? `port ${port} is taken`
                        : `ports ${port}–${last} are all taken (${span} tracker servers already run): close some agent sessions or set DMA_TRACKER_PORT`,
                );
            }
            if (closed) {
                candidate.close();
                throw new Error('the bridge was closed');
            }
            wss = candidate;
            wss.on('connection', onConnection);
            return wss.address().port;
        }
    })();
    listening.catch(() => {});

    return {
        ready: () => listening,
        status: () => ({ connected: Boolean(client), extensionVersion: clientVersion, port: wss?.address()?.port ?? port }),
        async call(method, params = {}, timeoutMs = requestTimeoutMs) {
            if (!client) {
                throw new Error(
                    'The DMA Time Tracker extension is not connected. Open Chrome with the extension installed and switch on "Agent bridge (MCP)" in its settings with the same token and port.',
                );
            }
            const id = (seq += 1);
            return new Promise((resolve, reject) => {
                const timer = setTimeout(() => {
                    pending.delete(id);
                    reject(new Error(`the extension did not answer "${method}" within ${Math.round(timeoutMs / 1000)} s`));
                }, timeoutMs);
                pending.set(id, { resolve, reject, timer });
                client.send(JSON.stringify({ type: 'request', id, method, params }));
            });
        },
        close() {
            closed = true;
            failAll('the bridge was closed');
            if (wss) {
                for (const ws of wss.clients) {
                    ws.terminate();
                }
                wss.close();
            }
        },
    };
}
