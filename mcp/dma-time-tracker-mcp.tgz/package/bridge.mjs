import { WebSocketServer } from 'ws';
import { proofFor, randomToken } from './lib/proof.js';

/**
 * Localhost WebSocket end of the agent bridge. The extension's service worker connects, both
 * sides prove the shared token, then the server forwards tool calls as requests and awaits the
 * extension's responses. One extension connection at a time; the newest wins.
 */
export function createBridge({ port, token, log = () => {}, host = '127.0.0.1', requestTimeoutMs = 90e3 }) {
    const wss = new WebSocketServer({ host, port, path: '/extension' });
    const listening = new Promise((resolve, reject) => {
        wss.once('listening', () => resolve(wss.address().port));
        wss.once('error', reject);
    });
    let client = null;
    let clientVersion = '';
    const pending = new Map();
    let seq = 0;

    const failAll = (reason) => {
        for (const entry of pending.values()) {
            clearTimeout(entry.timer);
            entry.reject(new Error(reason));
        }
        pending.clear();
    };

    wss.on('connection', (ws) => {
        const nonce = randomToken(16);
        let verified = false;
        ws.send(JSON.stringify({ type: 'challenge', nonce }));
        const ping = setInterval(() => {
            if (ws.readyState === ws.OPEN) {
                ws.send(JSON.stringify({ type: 'ping' }));
            }
        }, 20e3);
        ws.on('message', async (raw) => {
            let message;
            try {
                message = JSON.parse(String(raw));
            } catch {
                return;
            }
            if (message.type === 'hello') {
                if (message.proof !== (await proofFor(token, nonce)) || !message.nonce) {
                    log('a client failed the token proof');
                    ws.close(4001, 'bad token');
                    return;
                }
                verified = true;
                if (client && client !== ws) {
                    client.close(4003, 'replaced by a newer connection');
                }
                client = ws;
                clientVersion = message.version || '';
                ws.send(JSON.stringify({ type: 'welcome', proof: await proofFor(token, message.nonce) }));
                log(`extension connected (v${clientVersion})`);
                return;
            }
            if (!verified || message.type !== 'response') {
                return;
            }
            const entry = pending.get(message.id);
            if (!entry) {
                return;
            }
            pending.delete(message.id);
            clearTimeout(entry.timer);
            if (message.error) {
                entry.reject(new Error(message.error.message || 'the extension reported an error'));
            } else {
                entry.resolve(message.result);
            }
        });
        ws.on('close', () => {
            clearInterval(ping);
            if (client === ws) {
                client = null;
                clientVersion = '';
                failAll('the extension disconnected');
                log('extension disconnected');
            }
        });
        ws.on('error', () => {});
    });

    return {
        ready: () => listening,
        status: () => ({ connected: Boolean(client), extensionVersion: clientVersion, port: wss.address()?.port ?? port }),
        async call(method, params = {}, timeoutMs = requestTimeoutMs) {
            if (!client) {
                throw new Error(
                    'The DMA Time Tracker extension is not connected. Open Chrome with the extension installed and switch on "Agent bridge (MCP)" in its settings with the same token and port.',
                );
            }
            const id = (seq += 1);
            return new Promise((resolve, reject) => {
                const timer = setTimeout(() => {
                    pending.delete(id);
                    reject(new Error(`the extension did not answer "${method}" within ${Math.round(timeoutMs / 1000)} s`));
                }, timeoutMs);
                pending.set(id, { resolve, reject, timer });
                client.send(JSON.stringify({ type: 'request', id, method, params }));
            });
        },
        close() {
            failAll('the bridge was closed');
            for (const ws of wss.clients) {
                ws.terminate();
            }
            wss.close();
        },
    };
}
