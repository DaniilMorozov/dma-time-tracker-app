#!/usr/bin/env node
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { Server } from '@modelcontextprotocol/sdk/server/index.js';
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js';
import { CallToolRequestSchema, ListToolsRequestSchema } from '@modelcontextprotocol/sdk/types.js';
import { BRIDGE_PORT_SPAN, BRIDGE_PROTOCOL, createBridge } from './bridge.mjs';

/**
 * MCP server for the DMA YouTrack Time Tracker extension (stdio transport). It is a relay: the
 * tools, their descriptions and schemas come from the extension when it connects (and are cached
 * on disk for the next start); every call is forwarded to the extension. Updates of the extension
 * therefore reach agents without a new server; only a change of the bridge protocol needs one.
 *
 *   DMA_TRACKER_TOKEN=<token from the extension settings> [DMA_TRACKER_PORT=47631] node mcp/server.mjs
 *   (store users: npx -y https://daniilmorozov.github.io/dma-time-tracker-app/mcp/dma-time-tracker-mcp-<version>.tgz)
 *
 * Each agent session starts its own server: it takes the first free of BRIDGE_PORT_SPAN ports and
 * stops with the session (the client closes stdin; the SDK transport does not react to that by
 * itself). Chrome with the extension must be running and "Agent bridge (MCP)" switched on in its
 * settings.
 */

const here = path.dirname(fileURLToPath(import.meta.url));
const { version } = JSON.parse(fs.readFileSync(path.join(here, 'package.json'), 'utf8'));
const token = (process.env.DMA_TRACKER_TOKEN || '').trim();
if (!token) {
    console.error('DMA_TRACKER_TOKEN is not set: copy the token from the extension settings (Agent bridge).');
    process.exit(1);
}
const port = Number(process.env.DMA_TRACKER_PORT) || 47631;
const cacheDir = process.env.DMA_TRACKER_CACHE || path.join(os.homedir(), '.cache', 'dma-time-tracker-mcp');
const cacheFile = path.join(cacheDir, 'tools.json');
const log = (message) => console.error(`[dma-tracker-mcp] ${message}`);

const STATUS_TOOL = {
    name: 'bridge_status',
    description: 'Whether the DMA Time Tracker extension is connected to this server, its version, and which tools it has listed (from the extension or from the cache of the last start).',
    inputSchema: { type: 'object', properties: {}, additionalProperties: false },
};
const text = (data) => ({ content: [{ type: 'text', text: JSON.stringify(data, null, 2) }] });
const failure = (message) => ({ isError: true, content: [{ type: 'text', text: message }] });

let tools = [];
let toolsFrom = 'none';
let toolsVersion = '';
try {
    const cached = JSON.parse(fs.readFileSync(cacheFile, 'utf8'));
    if (Array.isArray(cached.tools)) {
        tools = cached.tools;
        toolsFrom = 'cache';
        toolsVersion = String(cached.version || '');
    }
} catch {
    /* nothing cached yet */
}

const server = new Server({ name: 'dma-time-tracker', version }, { capabilities: { tools: { listChanged: true } } });
let started = false;
let refreshing = null;

async function fetchTools() {
    let answer;
    try {
        answer = await bridge.call('tools', {}, 15e3);
    } catch (e) {
        log(`the extension did not list its tools (${e.message}); ${tools.length ? `keeping the ${tools.length} known ones` : 'only bridge_status is available'}`);
        return;
    }
    const list = (Array.isArray(answer?.tools) ? answer.tools : []).filter((t) => t && t.name && t.method && t.inputSchema);
    const changed = JSON.stringify(list) !== JSON.stringify(tools);
    tools = list;
    toolsFrom = 'extension';
    toolsVersion = String(answer?.version || '');
    log(`${list.length} tools from the extension v${toolsVersion}${changed ? '' : ' (unchanged)'}`);
    if (!changed) {
        return;
    }
    try {
        fs.mkdirSync(cacheDir, { recursive: true });
        fs.writeFileSync(cacheFile, JSON.stringify({ version: toolsVersion, tools: list }));
    } catch (e) {
        log(`cannot cache the tools: ${e.message}`);
    }
    if (started) {
        server.sendToolListChanged().catch(() => {});
    }
}

const refreshTools = () => {
    if (!refreshing) {
        refreshing = fetchTools().finally(() => {
            refreshing = null;
        });
    }
    return refreshing;
};

const bridge = createBridge({ port, token, version, log, onConnect: () => refreshTools() });

const waitForExtension = async (ms) => {
    const until = Date.now() + ms;
    while (!bridge.status().connected && Date.now() < until) {
        await new Promise((resolve) => setTimeout(resolve, 100));
    }
    return bridge.status().connected;
};

server.setRequestHandler(ListToolsRequestSchema, async () => {
    if (!tools.length && (await waitForExtension(3000))) {
        await refreshTools();
    }
    return { tools: [STATUS_TOOL, ...tools.map(({ name, description, inputSchema }) => ({ name, description, inputSchema }))] };
});

server.setRequestHandler(CallToolRequestSchema, async ({ params }) => {
    const name = params.name;
    if (name === STATUS_TOOL.name) {
        return text({ ...bridge.status(), protocol: BRIDGE_PROTOCOL, serverVersion: version, tools: tools.length, toolsFrom, toolsVersion });
    }
    const tool = tools.find((t) => t.name === name);
    if (!tool) {
        return failure(
            tools.length
                ? `Unknown tool "${name}"`
                : `Unknown tool "${name}": the extension has not listed its tools yet. Is Chrome with the extension running and "Agent bridge (MCP)" switched on with this token?`,
        );
    }
    try {
        return text(await bridge.call(tool.method, params.arguments || {}));
    } catch (e) {
        return failure(e.message);
    }
});

let stopping = false;
const stop = (why, code = 0) => {
    if (stopping) {
        return;
    }
    stopping = true;
    log(`${why}; stopping`);
    bridge.close();
    process.exit(code);
};
process.stdin.on('end', () => stop('the client closed the connection'));
process.stdin.on('close', () => stop('the client closed the connection'));
for (const signal of ['SIGINT', 'SIGTERM', 'SIGHUP']) {
    process.on(signal, () => stop(signal));
}
let listeningOn;
try {
    listeningOn = await bridge.ready();
} catch (e) {
    stop(`cannot listen: ${e.message}`, 1);
}
log(
    listeningOn === port
        ? `listening for the extension on 127.0.0.1:${port}`
        : `listening for the extension on 127.0.0.1:${listeningOn} (${port} is used by another agent's server; the extension connects to all ${BRIDGE_PORT_SPAN} ports from ${port})`,
);
if (tools.length) {
    log(`${tools.length} tools known from the last start (extension v${toolsVersion})`);
}

server.onclose = () => stop('the client disconnected');
await server.connect(new StdioServerTransport());
started = true;
log('ready');
