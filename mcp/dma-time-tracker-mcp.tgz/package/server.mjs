#!/usr/bin/env node
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js';
import { z } from 'zod';
import { createBridge } from './bridge.mjs';
import { ACTIVITY_TYPES } from './lib/activity-types.js';

/**
 * MCP server for the DMA YouTrack Time Tracker extension (stdio transport, read-only tools).
 *
 *   DMA_TRACKER_TOKEN=<token from the extension settings> [DMA_TRACKER_PORT=47631] node mcp/server.mjs
 *   (store users: npx -y https://daniilmorozov.github.io/dma-time-tracker-app/mcp/dma-time-tracker-mcp.tgz)
 *
 * Every tool is answered by the extension through the local bridge, so Chrome with the extension
 * must be running and "Agent bridge (MCP)" switched on in its settings.
 */

const here = path.dirname(fileURLToPath(import.meta.url));
const { version } = JSON.parse(fs.readFileSync(path.join(here, 'package.json'), 'utf8'));
const token = (process.env.DMA_TRACKER_TOKEN || '').trim();
if (!token) {
    console.error('DMA_TRACKER_TOKEN is not set: copy the token from the extension settings (Agent bridge).');
    process.exit(1);
}
const port = Number(process.env.DMA_TRACKER_PORT) || 47631;
const log = (message) => console.error(`[dma-tracker-mcp] ${message}`);
const bridge = createBridge({ port, token, log });
await bridge.ready();
log(`listening for the extension on 127.0.0.1:${port}`);

const server = new McpServer({ name: 'dma-time-tracker', version });
const today = () => {
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
};
const date = z.string().regex(/^\d{4}-\d{2}-\d{2}$/, 'YYYY-MM-DD').optional().describe('Day as YYYY-MM-DD; today when omitted');
const text = (data) => ({ content: [{ type: 'text', text: JSON.stringify(data, null, 2) }] });
const viaBridge = async (method, params) => {
    try {
        return text(await bridge.call(method, params));
    } catch (e) {
        return { isError: true, content: [{ type: 'text', text: e.message }] };
    }
};
const tool = (name, description, shape, run) => server.registerTool(name, { description, inputSchema: shape }, run);

tool('bridge_status', 'Whether the DMA Time Tracker extension is connected to this server, and its version.', {}, async () => text(bridge.status()));
tool('get_settings', "The tracker's settings without secrets (tokens are reported as present/absent).", {}, () => viaBridge('settings', {}));
tool(
    'get_day',
    'The time entries of a day as prepared in the tracker: issue id, summary, company, type, hours, description, sent status, flags (commented / state changed / assigned / via Assistant), the YouTrack issues opened that day (visits) and sync warnings.',
    { date },
    ({ date: d }) => viaBridge('day', { date: d || today() }),
);
tool(
    'list_days',
    'Per-day summary (entries, hours, sent, pending) for a range of days, at most 62. Defaults to the last 7 days.',
    { from: date, to: date },
    ({ from, to }) => viaBridge('days', { from, to }),
);
tool(
    'get_month',
    "A month's calendar as the tracker shows it: hours reported on the DialMyApp Panel per day and day types (weekend, holiday, vacation, short day) from the corporate time tracker. fresh=true re-reads the panel.",
    { month: z.string().regex(/^\d{4}-\d{2}$/, 'YYYY-MM').optional().describe('Month as YYYY-MM; the current month when omitted'), fresh: z.boolean().optional() },
    ({ month, fresh }) => viaBridge('month', { month, fresh }),
);
tool('get_panel_activities', 'The time entries already reported on the DialMyApp Panel for a day (live).', { date }, ({ date: d }) => viaBridge('panel_activities', { date: d || today() }));
tool(
    'get_claude_activity',
    'How long Claude Code agents worked on a day, chat by chat: title, project, work time, prompts, replies, tool calls, tokens, models, the YouTrack issue a chat is about. Needs the Claude Code folder chosen in the tracker.',
    { date },
    ({ date: d }) => viaBridge('claude', { date: d || today() }),
);
tool(
    'get_github_activity',
    "The day's GitHub activity of the configured token's user: repositories → branches → commits, pull requests with state, reviews, comments, and the YouTrack issues they mention.",
    { date },
    ({ date: d }) => viaBridge('github', { date: d || today() }),
);
tool(
    'get_chat_activity',
    "The day's Google Chat conversations the user took part in: who (direct message partner or space), time talked, messages, sessions. Needs Google Chat connected in the tracker.",
    { date },
    ({ date: d }) => viaBridge('chat', { date: d || today() }),
);
tool('get_youtrack_issue', 'A YouTrack issue by id (summary, project, Company name field, state) through the tracker\'s token.', { id: z.string().describe('Issue id such as DMA-30660') }, ({ id }) => viaBridge('youtrack_issue', { id }));
tool(
    'search_youtrack',
    'Search YouTrack issues with a YouTrack query, e.g. "updated: 2026-11-05 and updater: me".',
    { query: z.string(), top: z.number().int().min(1).max(200).optional() },
    ({ query, top }) => viaBridge('youtrack_search', { query, top }),
);
tool('get_companies', "The DialMyApp Panel's company list (names accepted in time entries).", {}, () => viaBridge('companies', {}));
tool('get_favorites', "The user's favourite activities and their weekly schedules.", {}, () => viaBridge('favorites', {}));

const hours = z.union([z.number().positive(), z.string()]).describe('Hours as a number (1.5) or text ("1h 30m", "45m"); rounded to the tracker\'s step');
const type = z.enum(ACTIVITY_TYPES).optional().describe('Activity type; the tracker\'s default when omitted');
const WRITE_NOTE = ' Needs "Allow agents to add, change and remove entries and to send time" switched on in the tracker settings.';
tool(
    'sync_day',
    'Rebuild the day from YouTrack activity (issues commented, moved, assigned; calendar meetings; scheduled favourites) like the ⟳ button of the tracker; existing hours stay. Returns the entries with their uids.' + WRITE_NOTE,
    { date },
    ({ date: d }) => viaBridge('sync_day', { date: d || today() }),
);
tool(
    'add_entry',
    'Add a time entry to a day, locally (not sent yet). With issueId the summary, description and company come from YouTrack; company names are matched against the panel list and aliases.' + WRITE_NOTE,
    {
        date,
        issueId: z.string().optional().describe('YouTrack issue id such as DMA-30660'),
        company: z.string().optional().describe('Panel company; required without an issue id when no default company is set'),
        type,
        hours,
        description: z.string().optional().describe('Defaults to "<issue id> <summary>"; required without an issue id'),
    },
    ({ date: d, ...rest }) => viaBridge('add_entry', { date: d || today(), ...rest }),
);
tool(
    'update_entry',
    'Change an entry of a day by uid (from get_day / sync_day / add_entry): company, type, hours, description, skipped. Changed hours are locked against redistribution.' + WRITE_NOTE,
    { date, uid: z.string(), company: z.string().optional(), type, hours: hours.optional(), description: z.string().optional(), skipped: z.boolean().optional().describe('true keeps the entry but excludes it from the total and from sending') },
    ({ date: d, ...rest }) => viaBridge('update_entry', { date: d || today(), ...rest }),
);
tool(
    'remove_entry',
    'Remove an entry of a day by uid; an entry already reported is deleted on the panel too.' + WRITE_NOTE,
    { date, uid: z.string() },
    ({ date: d, uid }) => viaBridge('remove_entry', { date: d || today(), uid }),
);
tool(
    'send_day',
    "Report the day's entries to the DialMyApp Panel (new entries are created, changed ones updated; skipped and unchanged ones are left alone), all of them or only the given uids. This is the real time report; check get_day first. Returns a result per entry." + WRITE_NOTE,
    { date, uids: z.array(z.string()).optional().describe('Only these entries; all pending ones when omitted') },
    ({ date: d, uids }) => viaBridge('send_day', { date: d || today(), uids }),
);

await server.connect(new StdioServerTransport());
log('ready');
